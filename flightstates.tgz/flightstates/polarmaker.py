#!/usr/bin/env python3
"""
polarmaker.py — run 1 of 2: measure the effective sink polar per glider type.

Reads IGC files and writes ONE small table (polars.csv) and nothing else:
per glider type, the glider's sink at airspeeds 25-65 km/h, measured from the
glide legs of all its flights. No positions, no times, no pilots, no flight
data of any kind leave this script — the table is a few kilobytes and can be
inspected line by line before anything else is run.

Why this table exists: run 2 (flightstates.py) cuts a flight into segments
where the AIR changes, not where the vario changes. For that it must subtract
the glider's own sink at the momentary airspeed — and that curve differs from
glider to glider. Estimated from a single flight it scatters by 0.21 m/s;
averaged over 50+ flights of the same type it settles to +-0.03.

Method, per flight: circling episodes give the wind (drift over full turns);
every non-circling run of >= 30 s is a glide leg; its airspeed is the
displacement minus the wind drift over the leg, its sink is the height
difference over the duration. Legs are pooled per NORMALISED glider name and
the median sink is taken per 5 km/h airspeed band. This is the EFFECTIVE
polar — the glider in the air it actually flew through — which is exactly
what run 2 needs to subtract.

Names: lower-cased, punctuation stripped, a few manufacturer aliases. Digits
are never touched and no fuzzy matching is done — "zeolite gt" and
"zeolite 2 gt" are different gliders. Typos stay separate rows and fall
below the --min threshold on their own.

    python3 polarmaker.py "flights/**/*.IGC" --out polars.csv
    python3 polarmaker.py "flights/**/*.IGC" --part 2/4 --out part2.csv
    python3 polarmaker.py --join "part*.csv" --out polars.csv

Dependencies: numpy, pandas, scipy, and flightstates.py beside this file.
"""
import argparse, glob, re, sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import flightstates as fs                                    # noqa: E402

SPEEDS = list(range(25, 66, 5))          # band centres, km/h (width 5)
MIN_LEG_S = 30                           # s, shorter legs are ignored
MIN_LEGS_CELL = 40                       # legs needed before a cell is written

ALIAS = {"ozon": "ozone", "adv": "advance", "nivuk": "niviuk"}


def normalise(name):
    """Lower-case, strip punctuation, alias manufacturers. Digits untouched."""
    s = re.sub(r"[^a-z0-9 ]", " ", name.lower())
    s = re.sub(r"\b(paraglider|glider|wing|pg)\b", " ", s)
    return " ".join(ALIAS.get(w, w) for w in s.split())


def legs_of(path):
    """(glider, [(airspeed_kmh, sink_ms, dur_s), ...]) of one flight."""
    day, glider, t0, raw = fs.read_igc(path)
    df = fs.resample_1hz(raw)
    dh, net = fs.turn_signal(df)
    wx, wy, wk = fs.wind_series(df, dh, net)
    circ = fs.circling_per_second(df, net, wk)
    x = df["x"].to_numpy(); y = df["y"].to_numpy(); h = df["alt_g"].to_numpy()
    out = []
    for a, b in fs.runs_of(~circ):
        dt = b - a
        if dt < MIN_LEG_S:
            continue
        ex = (x[b] - x[a]) - wx[a:b + 1].mean() * dt
        ey = (y[b] - y[a]) - wy[a:b + 1].mean() * dt
        v = float(np.hypot(ex, ey) / dt * 3.6)
        s = float((h[b] - h[a]) / dt)
        if 18 < v < 75 and -5 < s < 1.5:
            out.append((v, s, float(dt)))
    return normalise(glider), out


def write_table(dest, sammel, min_flights):
    rows = []
    for name, (fl, legs) in sammel.items():
        if not name or len(fl) < min_flights or not legs:
            continue
        L = np.array(legs)
        cells = []
        for c in SPEEDS:
            m = (L[:, 0] >= c - 2.5) & (L[:, 0] < c + 2.5)
            cells.append(f"{np.median(L[m, 1]):.2f}" if m.sum() >= MIN_LEGS_CELL else "")
        if sum(1 for c in cells if c) >= 3:
            rows.append((name, len(fl), len(legs), cells))
    rows.sort(key=lambda r: -r[1])
    with open(dest, "w", encoding="utf-8") as f:
        f.write("# flightstates polar table 1.0\n")
        f.write("# effective sink [m/s] of the glider in the air it flew, "
                "per airspeed band [km/h]\n")
        f.write("glider;flights;legs;" + ";".join(str(c) for c in SPEEDS) + "\n")
        for name, nf, nl, cells in rows:
            f.write(f"{name};{nf};{nl};" + ";".join(cells) + "\n")
    print(f"{dest}: {len(rows)} rows, {Path(dest).stat().st_size} bytes")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("globs", nargs="*")
    ap.add_argument("--out", default="polars.csv")
    ap.add_argument("--part", default="1/1", help="k/n for parallel runs")
    ap.add_argument("--min", type=int, default=20,
                    help="flights needed before a glider gets a row (use 50+ "
                         "on a large archive)")
    ap.add_argument("--join", default=None,
                    help="glob of part tables to merge instead of reading IGCs")
    a = ap.parse_args()

    if a.join:
        sammel = {}
        for part in sorted(glob.glob(a.join)):
            for z in open(part, encoding="utf-8"):
                if z.startswith("#") or z.startswith("glider;"):
                    continue
                f = z.rstrip("\n").split(";")
                name, nf, nl = f[0], int(f[1]), int(f[2])
                fl, legs = sammel.setdefault(name, (set(), []))
                # parts carry aggregated cells; re-merge via weighted rows
                fl.update(range(len(fl), len(fl) + nf))
                for c, cell in zip(SPEEDS, f[3:]):
                    if cell:
                        legs += [(c, float(cell), 1.0)] * (nl // len(SPEEDS) + 1)
        write_table(a.out, sammel, a.min)
        return

    files = []
    for g in a.globs:
        files += glob.glob(g, recursive=True)
    einmal = {}
    for d in sorted(files):
        einmal.setdefault(Path(d).name, d)
    files = sorted(einmal.values())
    k, n = (int(x) for x in a.part.split("/"))
    files = files[k - 1::n]

    sammel = {}                       # name -> (set of flight indices, legs)
    alle = []
    for i, p in enumerate(files, 1):
        try:
            name, legs = legs_of(p)
        except Exception as e:
            print(f"# {Path(p).name}: {type(e).__name__}: {e}", file=sys.stderr)
            continue
        fl, ll = sammel.setdefault(name, (set(), []))
        fl.add(i); ll += legs
        alle += legs
        if i % 100 == 0:
            print(f"  {i}/{len(files)}", file=sys.stderr)
    sammel["_general"] = (set(range(len(files))), alle)
    write_table(a.out, sammel, a.min)


if __name__ == "__main__":
    main()
