#!/usr/bin/env python3
"""chart.py — one plate: a flying day in seven states.

  python3 chart.py flight.IGC --out plate.png --language en
  python3 chart.py flight.IGC --out plate.png --raw

--raw puts the untouched trace on top, exactly as it comes out of the IGC
file, and the same trace below it with every second sorted into a state. That
is the whole difference this package makes, in one picture.
"""
import argparse, os, sys
from pathlib import Path
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
sys.path.insert(0, str(Path(__file__).resolve().parent))
import flightstates as xs

COLOUR = {"K": "#d68a00",   # circling, climbing
          "k": "#8a5a2a",   # circling, no gain
          "G": "#1f5fa8",   # straight, climbing
          "T": "#0e8a8a",   # air rising
          "R": "#9a968c",   # calm air
          "L": "#4a5a6a",   # sinking air
          "S": "#1b2a3a"}   # strongly sinking air
LW = {"R": 1.4, "L": 1.6, "S": 2.0, "T": 2.2, "K": 2.8, "k": 2.2, "G": 3.0}
BG = "#f2e4c8"
W = {"de": dict(K="Kreissteigen", k="Kreisen ohne Gewinn", G="Geradeaussteigen",
                T="hebende Luft", R="ruhige Luft", L="sinkende Luft",
                S="stark sinkende Luft", hoehe="Höhe MSL [m]", vario="Vario\n[m/s]",
                zust="Zustand", wind="[km/h]", zeit="Ortszeit",
                wl="Wind aus der Kreisdrift", vk="Vorankommen je Segment",
                roh="Die IGC-Datei, so wie sie ankommt",
                unser="Dieselbe Spur, jede Sekunde einem Zustand zugeordnet"),
     "en": dict(K="circling climb", k="circling, no gain", G="straight climb",
                T="air rising", R="calm air", L="sinking air",
                S="strongly sinking air", hoehe="altitude MSL [m]", vario="vario\n[m/s]",
                zust="state", wind="[km/h]", zeit="local time",
                wl="wind from circling drift", vk="progress per segment",
                roh="The IGC file, as it arrives",
                unser="The same track, every second sorted into a state")}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("igc"); ap.add_argument("--out", default="tafel.png")
    ap.add_argument("--language", default="de", choices=("de", "en"))
    ap.add_argument("--width", type=int, default=4500)
    ap.add_argument("--raw", action="store_true",
                    help="add the untouched trace as a panel on top")
    ap.add_argument("--title", default="")
    a = ap.parse_args(); w = W[a.language]

    poldat = Path(__file__).resolve().parent / "polars.csv"
    polars = xs.load_polars(poldat) if poldat.exists() else None
    tag, glider, src, segs, ende, df = xs.segments(a.igc, polars)
    _, _, t0, _ = xs.read_igc(a.igc)
    n = len(df)
    std = (t0 + df["t"].to_numpy()) / 3600.0 + 2.0
    alt = df["alt_g"].to_numpy(); vario = df["vario"].to_numpy()
    la = df["lat"].to_numpy(); lo = df["lon"].to_numpy()
    kind = np.array([" "] * n, dtype="<U1")
    for s in segs:
        kind[s["a"]:s["b"] + 1] = s["kind"]
    kind[kind == " "] = segs[-1]["kind"]
    wind = np.full(n, np.nan); pt, pv = [], []
    for s in segs:
        if s["kind"] in "Kk" and s.get("drift") is not None:
            pt.append(0.5 * (s["a"] + s["b"])); pv.append(s["drift"])
    wind = np.interp(np.arange(n), pt, pv) if len(pt) >= 2 else np.zeros(n)
    vk = np.zeros(n)
    for s in segs:
        d = max(s["b"] - s["a"], 1)
        vk[s["a"]:s["b"] + 1] = 3.6 * np.hypot(
            (lo[s["b"]] - lo[s["a"]]) * 111320 * np.cos(np.radians(la[s["a"]])),
            (la[s["b"]] - la[s["a"]]) * 111132) / d

    DPI = 100
    hr = ([4.2, 5, 1.6, .7, 1.5] if a.raw else [5, 1.6, .7, 1.5])
    H = int(a.width * (0.205 if a.raw else 0.155))
    fig, ax = plt.subplots(len(hr), 1, figsize=(a.width / DPI, H / DPI), dpi=DPI,
                           sharex=True, gridspec_kw=dict(height_ratios=hr, hspace=.16 if a.raw else .08))
    fig.patch.set_facecolor("#eef0ea")
    for x in ax:
        x.set_facecolor(BG); x.grid(True, axis="x", color="#c9b697", lw=.6); x.margins(x=.002)
    if a.raw:
        roh = ax[0]
        roh.plot(std, alt, color="#3a3833", lw=1.0)
        roh.set_ylabel(w["hoehe"])
        roh.set_title(w["roh"], loc="left", fontsize=12, fontweight="bold", pad=8)
        ax = ax[1:]
        ax[0].set_title(w["unser"], loc="left", fontsize=12, fontweight="bold", pad=8)
    ax[0].plot(std, alt, color="#a89f90", lw=.6, zorder=2)
    gr = np.concatenate(([0], np.flatnonzero(kind[1:] != kind[:-1]) + 1, [n]))
    for i in range(len(gr) - 1):
        p, q = gr[i], gr[i + 1]
        ax[0].plot(std[p:q], alt[p:q], color=COLOUR[kind[p]], lw=LW[kind[p]],
                   zorder=3, solid_capstyle="round")
    ax[0].set_ylabel(w["hoehe"])
    from matplotlib.lines import Line2D
    ax[0].legend(handles=[Line2D([], [], color=COLOUR[k], lw=3, label=w[k])
                          for k in "KGTRLSk"], loc="upper left", ncols=5,
                 fontsize=11, framealpha=.7)
    if a.title and not a.raw:
        ax[0].set_title(a.title, loc="left", fontsize=12, fontweight="bold", pad=8)
    elif a.title and a.raw:
        fig.suptitle(a.title, x=0.008, ha="left", fontsize=13, fontweight="bold")
    ax[1].fill_between(std, 0, vario, where=vario >= 0, color=COLOUR["K"], alpha=.75, lw=0)
    ax[1].fill_between(std, 0, vario, where=vario < 0, color="#4a6a8a", alpha=.75, lw=0)
    ax[1].axhline(0, color="#333", lw=.6); ax[1].set_ylim(-4, 5); ax[1].set_ylabel(w["vario"])
    code = np.array([list(COLOUR).index(c) for c in kind])
    ax[2].pcolormesh(std, [0, 1], code[np.newaxis, :n - 1],
                     cmap=mcolors.ListedColormap(list(COLOUR.values())),
                     vmin=0, vmax=len(COLOUR) - 1)
    ax[2].set_yticks([]); ax[2].set_ylabel(w["zust"], rotation=0, ha="right", va="center")
    ax[3].plot(std, vk, color="#333", lw=.9, label=w["vk"])
    ax[3].plot(std, wind, color=COLOUR["G"], lw=1.8, label=w["wl"])
    ax[3].set_ylim(0, 90); ax[3].set_ylabel(w["wind"])
    ax[3].legend(loc="upper left", fontsize=10, ncols=2, framealpha=.6)
    ticks = np.arange(np.ceil(std[0] * 4) / 4, std[-1], .25)
    for x in ax:
        x.set_xticks(ticks)
    ax[3].set_xticklabels([f"{int(t):02d}:{int(round((t % 1) * 60)):02d}"
                           if abs((t * 2) % 1) < 1e-6 else "" for t in ticks], fontsize=10)
    ax[3].set_xlabel(w["zeit"])
    fig.savefig(a.out, facecolor=fig.get_facecolor())
    print(a.out, a.width, H, len(segs), "segments")


if __name__ == "__main__":
    main()
