# flightstates — flight track in, state list out

This is a segmenter for IGC flight tracks. It reads a track and writes, for
every flight, **one line of text** describing the flight as a sequence of
**states**: contiguous stretches in which the pilot is doing one thing — or,
on a glide, in which the air is doing one thing.

The unit is the **second**, not the thermal. Every second gets two properties —
is the pilot circling, and what is the air doing — and a segment is a
contiguous run of equal seconds. A thermal is therefore simply a run of
"circling and climbing", and it stands beside "straight and climbing" as an
equal. That is the point of the whole exercise: a detector built around
thermals cannot see the air that carries a pilot **without** circling, and it
is that air that decides a cross-country flight.

| Code | State | what it is |
|---|---|---|
| `K` | circling climb | gaining height turning in a thermal |
| `k` | circling, no gain | failed attempt, sinking out in a turn |
| `G` | **straight climb** | gaining height without turning — ridge lift, convergence, cloud street |
| `T` | **air rising** | not enough to climb, but the air is lifting |
| `R` | calm air | the air is neither rising nor sinking |
| `L` | sinking air | |
| `S` | strongly sinking air | |

The first three say what the *pilot* is doing. The last four are all glides and
say what the *air* is doing — which is the thing a route model needs to know.
Every glide segment carries that as a number too: `w`, the vertical movement of
the air in m/s, with the glider's own sink at the flown airspeed already
removed. A map can be coloured from it directly.

`flightstates.py` runs on its own — copy that one file anywhere and it works.
It needs `numpy`, `pandas` and `scipy`, nothing else: no maps, no terrain, no
weather, no network, no database. `polarmaker.py`, `verify.py` and `chart.py`
expect it beside them; the two drawing scripts also need `matplotlib`.

---

## Two runs, and a checkpoint between them

Separating the air from the vario needs the glider's own sink at the flown
airspeed — and that curve differs from glider to glider. So the work is two
runs, and the first one produces something you can inspect before anything
else happens:

**Run 1 — `polarmaker.py`** reads all IGC files and writes ONE small table,
`polars.csv`: per glider type, the measured sink at airspeeds 25–65 km/h.
A few hundred rows, a few kilobytes. **No positions, no times, no pilots, no
flight data of any kind** — every line can be read by eye, and the polars of
gliders you know should look plausible. If they don't, stop here; nothing has
left the machine.

```bash
python3 polarmaker.py "flights/**/*.IGC" --out polars.csv --min 50
```

**Run 2 — `flightstates.py`** segments every flight using that table and
writes the state lines. The first line of the output records which table was
used, with its checksum, so every number stays recomputable.

```bash
python3 flightstates.py --delta "flights/**/*.IGC" > states.txt
```

Both runs parallelise with `--part k/n`; part tables from run 1 merge with
`polarmaker.py --join "part*.csv"`.

Why per glider type, not per flight: estimated from a single flight, a
glider's sink scatters by 0.21 m/s — as much as the air movement one wants to
measure — while per type, over 50 flights or more, it settles to ±0.03. The
type is taken from the `HFGTY` record of the IGC header and names no person.
Names are normalised (case, punctuation, a few manufacturer aliases) but
**digits are never touched and nothing fuzzy happens** — "zeolite gt" and
"zeolite 2 gt" stay different gliders, and typo variants simply fall below
`--min` on their own. Flights whose glider has no table row use the
`_general` row; which one was used is recorded per flight.

---

## Why it may be worth your while

Measured on 774 alpine cross-country flights of two pilots
(2 883 flying hours, 75 849 km):

| State | pieces | time | distance | height | speed |
|---|---:|---:|---:|---:|---:|
| circling climb | 22 517 | 40.0 % | 11.0 % | +4 633 021 m | 7.3 km/h |
| circling, no gain | 7 737 | 5.4 % | 1.8 % | −275 753 m | 8.5 km/h |
| **straight climb** | 14 864 | **7.3 %** | **10.4 %** | **+547 407 m** | **37.5 km/h** |
| **air rising** | 7 929 | **4.5 %** | **7.4 %** | −85 285 m | **43.3 km/h** |
| calm air | 46 365 | 32.6 % | 52.3 % | −3 392 798 m | 42.2 km/h |
| sinking air | 13 339 | 9.2 % | 15.5 % | −1 787 330 m | 44.1 km/h |
| strongly sinking air | 1 834 | 1.0 % | 1.6 % | −283 549 m | 43.6 km/h |

Climbing without a single circle brings **547 407 m**, about an eighth of what
the thermals bring — but at 37 km/h of progress instead of 7. Add the air that
rises without carrying the pilot up, and almost a fifth of the whole distance
is flown in air that is working for him. On the strongest day in the set, the
straight climbing alone rises to 18 % of the time and 37 % of the day's gain.

A climb database records the climbs: 40 % of the flying time, 90 % of the
height gain — but **11 % of the distance**. The 89 % of the distance on which
cross-country flying actually happens does not appear in it.

The same is true of what could in principle be inferred from a climb database.
One crude rule can be applied to both sides: a climb counts as straight if the
displacement between entry and exit exceeds 25 km/h. That threshold is not a
standard — it was calibrated here, on tracks segmented second by second, where
the circling climbs sit at 9.2 km/h and the straight ones at 38.4 km/h, and the
cut catches 98 % of the straight climbs while misreading 3 % of the circling
ones. Applied to a database of 6.17 million climbs it marks **2.26 %** as
straight; applied to 9 503 climbs of the same kind of flying, decomposed
second by second, **24.6 %**. The difference is not in the flying; it is in the
decomposition. What is not delimited as a climb of its own cannot appear as a
straight climb either.

![the IGC file, and the same flight in seven states](example_day.png)

*One flying day. On top the IGC file as it arrives — 38 091 GPS fixes, one
altitude curve. Below the same track, every second sorted into a state, and the
whole flight written as 425 segments. Blue: climbing without circling. Teal:
air rising. Grey: calm air.*

---

## How a state is found

Three layers, each of which can be checked on its own.

### Layer 1 — 1 Hz and smoothing

The track is resampled to 1 Hz by linear interpolation. Height is smoothed with
a Savitzky-Golay filter (window 15 s, order 2) and the vario is the derivative
of that, averaged over 15 s. Barometric altitude is used when its spread says
it is real, otherwise GPS altitude.

### Layer 2 — is he circling (per second)

For every second the **signed heading change over a centred 20 s window** is
summed. A second counts as **straight** only if both hold:

1. `|sum of heading change over 20 s| <= 60 degrees` — a thermal circle takes
   15–25 s and accumulates 290–480 degrees in 20 s; a glide with course
   corrections stays far below 60.
2. `ground speed > 0.85 * wind(t)` — otherwise every drift in a thermal would
   count as straight flight.

This rule was checked against hand-calibrated circling marks: **94.7 %
agreement** outside the ±15 s transition edges.

### Layer 3 — where a segment ends, and what the air did there

The track is first split into circling and straight. A thermal stays whole and
does not fall apart at every dip in the climb; a circling piece takes its kind
(`K` or `k`) from the gain over the **whole** piece.

A straight run is then divided **where the air changes**, not where the vario
changes. The two differ: the vario is the air plus the glider's own sink, and
the own sink moves with the airspeed. Cut on the raw height and a pilot who
accelerates inside a glide gets a cut where nothing happened to the air, while
an air change masked by his speed change gets none — measured on this set,
about one cut in five sits in the wrong place that way, and a cut, unlike a
label, can never be corrected afterwards.

So the cutting works on the **air-corrected height**: the height minus the
glider's own accumulated sink, taken from its polar (run 1) at the momentary
airspeed, which is the ground velocity minus the wind measured from the
circling drift. On that curve — and on the ground plan — a joint
Douglas-Peucker sets as few corners as possible such that every piece keeps
**30 m** in the air-corrected height and **60 m** in position; 60 m is of the
order of a terrain grid cell, so a reconstructed track stays on the right side
of a ridge. The boundaries are a pure function of the geometry — no label
enters the cutting. Labels can be recomputed from the line at any time; cuts
cannot.

Each piece then gets its kind from its own slope: `G` if the pilot gains
height (raw slope above +0.10 m/s); otherwise from `w`, the slope of the
air-corrected height — the movement of the air:

| | `w` | share of the glide time (774 flights) |
|---|---|---:|
| `T` air rising | > +0.60 m/s | 9.5 % |
| `R` calm | −0.60 … +0.60 | 68.9 % |
| `L` sinking | −1.50 … −0.60 | 19.5 % |
| `S` strongly sinking | < −1.50 | 2.1 % |

These boundaries are conventions — the distribution of `w` is one broad bell
and offers no natural steps — but they sit on a measured quantity, and `w`
itself is written into every glide segment, so anyone can re-classify with
different boundaries without touching an IGC file again.

Runs shorter than 20 s are absorbed into the longer neighbour.

### The wind belongs to the thermal

A glider circling in a thermal drifts with the air, so every circling climb is
also a wind measurement. The method is taken over unchanged from an existing,
tested implementation:

* at least **1.5 full turns** and at least **30 s** — over full circles the
  airspeed averages out; a fixed duration alone does not achieve this;
* **four fixes trimmed at each end** — entry and exit are not circling, so the
  displacement between the raw endpoints is *not* the drift;
* drift above **40 km/h** discarded.

Each circling segment therefore carries three extra numbers: the turn count
(which is the quality of the measurement), the drift in km/h, and the direction
the air comes from. If the conditions are not met, the two wind fields stay
empty and only the turn count is written.

Note that this cannot be recovered from the line by anyone reading it: the
number of turns and the trimmed interior are not visible in the two endpoints.
That is why the measurement is stored rather than left to be recomputed.

---

## All thresholds at a glance

| Quantity | Value | where it comes from |
|---|---|---|
| sampling | 1 Hz | so recorders of different rates are comparable |
| height smoothing | Savitzky-Golay 15 s, order 2 | |
| vario averaging | 15 s | |
| turn window | 20 s | just under one circle (15–25 s) |
| turn threshold | 60 deg per 20 s | = 3 deg/s sustained |
| wind gate | ground speed > 0.85 × wind | drift is not straight flight |
| wind sample | ≥ 1.5 turns, ≥ 30 s, 4 fixes trimmed, ≤ 40 km/h | airspeed must average out over full circles |
| wind smoothing | 600 s running mean | otherwise episode steps look like fronts |
| climbing | raw slope > +0.10 m/s | |
| glider's own sink | per glider type from `polars.csv` (run 1) | measured, ±0.03 m/s at 50+ flights |
| air rising / calm / sinking / strong | w > +0.6 / ±0.6 / −1.5 m/s | conventions on the movement of the air |
| minimum run | 20 s | shorter runs are absorbed |
| height tolerance | 30 m | on the air-corrected height |
| position tolerance | 60 m | of the order of a terrain grid cell |
| coordinates | 5 decimals | about 1 m — the raw fix |

Every one of these is a constant at the top of `flightstates.py` or a cell in
`polars.csv`, and can be changed in one place.

---

## The output line

```
# flightstates 2.0 polars=polars.csv sha1=a48b1d37a814      <- file header, once
id;glider;pol;yyyymmdd;SEG|SEG|...;END

SEG straight (G,T,R,L,S):  A,t,h,lat,lon,w
SEG circling (K,k):        A,t,h,lat,lon,turns,drift_kmh,drift_from_deg
END:                         t,h,lat,lon
```

`A` is the kind, `t` the second of the day (UTC) at which the segment
**begins**, `h` the altitude MSL in metres, `lat,lon` the position — all at the
beginning of the segment. `w` is the vertical movement of the air over the
piece in m/s, own sink already removed. The **end** of a segment is the
**beginning of the next**, so it is not written twice; only the last point of
the flight gets an entry of its own.

`pol` is one character recording where the own-sink curve came from:
`g` = the glider's own row in the table, `a` = the `_general` row,
`n` = no table (a constant −1.11 m/s; segment cuts then coincide with cuts on
the raw height). The file header carries the table's checksum.

**The second field is the glider type**, straight from the `HFGTY` record.
It names no person. The line stores the type and nothing derived from it
beyond `w`; polar, airspeed and any re-classification belong in the analysis.

**The first field is yours.** This script never writes a name there; by default
it writes the single letter `P`. Fill it with whatever suits you — an anonymised
pilot key, a flight number of your own, a constant, or nothing at all. `--id
TEXT` sets it; `--id name` uses the file name, which only makes sense on your
own archive, since IGC file names usually carry the pilot's name.

If you do put an anonymised *pilot* key there, something becomes possible that no
single flight can show: how one pilot's technique develops over the years — when
the circling gets tighter, when the straight climbing starts to appear, how the
glides change. Two things could come of that, and both are yours to decide. I
would study it, but **anonymously only** — never a named pilot, in any
publication of mine. And you could turn it into something for your own users, a
personal progress report for paying XCTrack subscribers, for instance. It is an
offer, not a request: nothing in this package needs the field to be filled.

```
P;NIVIUK Artik 6;g;20230522;k,27039,1920,46.37603,8.02630,0.6,,|
R,27084,1917,46.37443,8.02672,-0.2|K,27125,1875,46.37130,8.02435,11.3,3.6,131|…
```

With `--delta` every number is written as the difference to the previous one.
Nothing is lost — `read_line_delta()` returns exactly what `read_line()`
returns, checked segment by segment — the numbers merely get short:

```
P;NIVIUK Artik 6;g;20230522;k27039,1920,4637603,802630,0.6,,|
R45,-3,-160,42,-0.2|K41,-42,-313,-237,11.3,3.6,131|…
```

`read_line()` and `read_line_delta()` in `flightstates.py` turn a line back
into a list of segments; lines starting with `#` are file headers to skip.

---

## Verification

`verify.py` draws the same picture twice: once from the real IGC file, once
from the text line alone, and prints the numeric comparison.

```bash
python3 verify.py flight.IGC --out check.png
```

For the day shown above:

```
height   : mean error  12.5 m, 90% under  28.4 m, largest  119 m
position : mean error    38 m, 90% under    85 m, largest  390 m
time share per state: identical, all seven
wind     : 52 measurements from 79 circling segments
```

Two honest notes on these numbers. The 30 m guarantee holds on the
**air-corrected** height; the raw height reconstructs slightly worse wherever
the pilot changed speed inside a piece — over the whole set the mean raw-height
error is 15 m and rare pieces reach ~300 m where speed changed hard. And the
position error has two parts, of which only the shape across the path is
bounded (60 m); along the path the linear interpolation cannot know that the
pilot flew faster or slower inside a segment. For a map, both are the harmless
kind.

![real against reconstructed](example_verify.png)

---

## Size and time

Measured on the 774 flights (2 883 flying hours, full 1 m / 1 s resolution,
`--delta`, `xz -6`):

```
8.1 bytes per segment          1 201 bytes per flight       323 bytes per flying hour
run 1 + run 2 together  about 30 ms per flying hour on one modern core
compression             negligible (~2 % of the work)
```

Scaled two ways: per climb (3.8 segments per circling piece, so 27.5 million
climbs become 104 million segments) that is **0.85 GB**; per flying hour,
taking three million flights of under two hours, **about 2 GB**. Reckon on
**one to two gigabytes**, compressed, and on the order of **one core-day** of
computing for a world archive — an afternoon on eight cores. `polars.csv`
itself is a few kilobytes.

Run it in parallel and concatenate:

```bash
for k in 1 2 3 4; do
  python3 flightstates.py --delta --part=$k/4 "flights/**/*.IGC" > part$k.txt &
done
wait
cat part*.txt | xz -6 > states.txt.xz
```

Each line is independent, so the output can be processed line by line without
loading the file.

---

## Files

| File | what it is |
|---|---|
| `flightstates.py` | the segmenter (run 2) — runs on its own, needs nothing else from here |
| `polarmaker.py` | run 1 — measures the sink polar per glider type, writes `polars.csv` |
| `polars.csv` | the polar table this package ships with — 774 flights, 10 rows; replace it with your own from run 1 |
| `verify.py` | real against reconstructed, picture and numbers |
| `chart.py` | one flying day in seven states, as a plate (`--raw` adds the untouched trace on top) |
| `example_line.txt` | one flight, full form |
| `example_line_delta.txt` | the same flight, compact form |
| `example_day.png`, `example_verify.png` | the two pictures above |
| `README.md`, `readme.html` | this text — as source and as a page to open |

## Origin and limits

* Layer 1 follows an existing fingerprint pipeline; layers 2 and 3, the state
  definitions and the polar table are this work.
* The wind method is taken over unchanged from a tested implementation and is
  not claimed as new here.
* The polar in `polars.csv` is the **effective** polar — the glider in the air
  it actually flew through, which is exactly what has to be subtracted here.
  It is not a manufacturer polar and will differ from one.
* Height comes from the barometer when its spread says it is real, otherwise
  from GPS. The date comes from the `HFDTE` record; if it is missing, from the
  file name. Times are UTC.
* Flights without valid B records are skipped and reported on stderr.
* The states are a decomposition, not an observation. Where a segment begins
  and ends is decided by the geometry and the tolerances; all the decisions
  are the constants above; change one and the whole output changes
  consistently.

Jörg Korner, 2026. Free to use.
