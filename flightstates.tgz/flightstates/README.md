# flightstates — flight track in, state list out

This is a segmenter for IGC flight tracks. It reads a track and writes, for
every flight, **one line of text** describing the flight as a sequence of
**states**: contiguous stretches in which the pilot is doing one thing.

The unit is the **second**, not the thermal. Every second gets two properties —
is the pilot circling, and what is the height doing — and a segment is a
contiguous run of equal seconds. A thermal is therefore simply a run of
"circling and climbing", and it stands beside "straight and climbing" as an
equal. That is the point of the whole exercise: a detector built around
thermals cannot see the air that carries a pilot **without** circling, and it
is that air that decides a cross-country flight.

| Code | State | what it is |
|---|---|---|
| `K` | circling climb | gaining height turning in a thermal |
| `k` | circling, no gain | failed attempt, sinking out in a turn |
| `G` | **straight climb** | gaining height without turning — ridge lift, convergence, cloud street |
| `T` | **air rising** | not enough to climb, but the sink is much reduced |
| `R` | calm air | the air is neither rising nor sinking |
| `L` | sinking air | |
| `S` | strongly sinking air | |

The first three say what the *pilot* is doing. The last four are all glides and
say what the *air* is doing — which is the thing a route model needs to know.

`flightstates.py` runs on its own — copy that one file anywhere and it works.
It needs `numpy`, `pandas` and `scipy`, nothing else: no maps, no terrain, no
weather, no network, no database. The other two scripts in this package,
`verify.py` and `chart.py`, draw pictures and therefore also need `matplotlib`;
both import `flightstates.py` and expect it beside them.

```bash
python3 flightstates.py --delta "flights/**/*.IGC" > states.txt
```

---

## Why it may be worth your while

Measured on 489 alpine cross-country flights (2 066 flying hours, 53 430 km) of
one pilot:

| State | pieces | time | distance | height | speed |
|---|---:|---:|---:|---:|---:|
| circling climb | 16 944 | 39.7 % | 10.7 % | +3 259 527 m | 6.9 km/h |
| circling, no gain | 5 339 | 5.0 % | 1.6 % | −175 203 m | 8.3 km/h |
| **straight climb** | 4 946 | **5.9 %** | **8.3 %** | **+315 301 m** | **36.3 km/h** |
| **air rising** | 6 386 | **8.8 %** | **12.3 %** | −156 325 m | **36.1 km/h** |
| calm air | 15 117 | 35.3 % | 57.2 % | −2 937 835 m | 41.9 km/h |
| sinking air | 2 348 | 5.0 % | 9.4 % | −723 930 m | 48.8 km/h |
| strongly sinking air | 190 | 0.2 % | 0.5 % | −50 204 m | 50.6 km/h |

Climbing without a single circle brings him **315 301 m**, a tenth of what the
thermals bring — but at 36 km/h of progress instead of 7. Add the air that is
rising without carrying him up, and **a fifth of his whole distance** is flown
in air that is working for him. On his strongest day the straight climbing
alone rises to 18 % of the time and 37 % of the day's gain.

A climb database records the climbs: 40 % of the flying time, 90 % of the
height gain — but **11 % of the distance**. The 89 % of the distance on which
cross-country flying actually happens does not appear in it.

The same is true of what could in principle be inferred from a climb database.
One crude rule can be applied to both sides: a climb counts as straight if the
displacement between entry and exit exceeds 25 km/h. That threshold is not a
standard — it was calibrated here, on tracks segmented second by second, where
the circling climbs sit at 9.2 km/h and the straight ones at 38.4 km/h, and the
cut catches 98 % of the straight climbs while misreading 3 % of the circling
ones. Applied to a database of 6.17 million climbs it marks **2.26 %** as
straight; applied to 9 503 climbs of the same kind of flying, decomposed
second by second, **24.6 %**. The difference is not in the flying; it is in the
decomposition. What is not delimited as a climb of its own cannot appear as a
straight climb either.

![the IGC file, and the same flight in seven states](example_day.png)

*One flying day. On top the IGC file as it arrives — 38 091 GPS fixes, one
altitude curve. Below the same track, every second sorted into a state, and the
whole flight written as 246 segments. Blue: climbing without circling. Teal:
air rising. Grey: calm air.*

---

## How a state is found

Three layers, each of which can be checked on its own.

### Layer 1 — 1 Hz and smoothing

The track is resampled to 1 Hz by linear interpolation. Height is smoothed with
a Savitzky-Golay filter (window 15 s, order 2) and the vario is the derivative
of that, averaged over 15 s. Barometric altitude is used when its spread says
it is real, otherwise GPS altitude.

### Layer 2 — is he circling (per second)

For every second the **signed heading change over a centred 20 s window** is
summed. A second counts as **straight** only if both hold:

1. `|sum of heading change over 20 s| <= 60 degrees` — a thermal circle takes
   15–25 s and accumulates 290–480 degrees in 20 s; a glide with course
   corrections stays far below 60.
2. `ground speed > 0.85 * wind(t)` — otherwise every drift in a thermal would
   count as straight flight.

This rule was checked against hand-calibrated circling marks: **94.7 %
agreement** outside the ±15 s transition edges.

### Layer 3 — where a segment ends

The track is first split into circling and straight. A thermal therefore stays
whole and does not fall apart at every dip in the climb; a circling piece takes
its kind (`K` or `k`) from the gain over the **whole** piece.

A straight piece is **not** chopped up by a per-second vario threshold — that
produces flicker between climbing and gliding and buys nothing. Instead the
height profile and the ground track divide it themselves (Douglas-Peucker):
only as many corners are set as are needed so that the reconstructed height is
never off by more than **60 m** and the position never by more than **300 m**.
Each resulting piece takes its kind from its own slope.

Runs shorter than 20 s are absorbed into the longer neighbour.

### The four kinds of glide

A piece that is not climbing is sorted by **what the air is doing**, not by the
vario. The two differ, because the vario also reflects how fast the pilot chose
to fly. The anchor is measured, not assumed: over **4.19 million seconds** of
straight flight (489 flights, 1 164 hours), the vario has a single broad peak at
**−1.11 m/s**. That is the glider's own sink in calm air — the most common
condition there is. What the air does is then

    w = vario − (−1.11)

and the boundaries are set in `w`:

| | `w` | vario | share of the straight-flying time |
|---|---|---|---:|
| `T` air rising | > +0.60 | > −0.51 | 35.3 % |
| `R` calm | −0.60 … +0.60 | −1.71 … −0.51 | 44.4 % |
| `L` sinking | −1.50 … −0.60 | −2.61 … −1.71 | 17.0 % |
| `S` strongly sinking | < −1.50 | < −2.61 | 3.3 % |

Two things should be said plainly. The peak has **no shoulders** — the
distribution is one broad bell with a long tail into the lift. There are no
natural boundaries in the data, so these four are conventions. But they are
anchored on a measurement and stated in the physical quantity, and both the
anchor and the three numbers are constants at the top of the file.

And a segment takes its class from its **own average slope**, so a short burst
of strong sink inside a longer piece does not show up as `S`. What `S` marks is
sustained strong sink — which is what matters for a route.

### The wind belongs to the thermal

A glider circling in a thermal drifts with the air, so every circling climb is
also a wind measurement. The method is taken over unchanged from an existing,
tested implementation:

* at least **1.5 full turns** and at least **30 s** — over full circles the
  airspeed averages out; a fixed duration alone does not achieve this;
* **four fixes trimmed at each end** — entry and exit are not circling, so the
  displacement between the raw endpoints is *not* the drift;
* drift above **40 km/h** discarded.

Each circling segment therefore carries three extra numbers: the turn count
(which is the quality of the measurement), the drift in km/h, and the direction
the air comes from. If the conditions are not met, the two wind fields stay
empty and only the turn count is written.

Note that this cannot be recovered from the line by anyone reading it: the
number of turns and the trimmed interior are not visible in the two endpoints.
That is why the measurement is stored rather than left to be recomputed.

---

## All thresholds at a glance

| Quantity | Value | where it comes from |
|---|---|---|
| sampling | 1 Hz | so recorders of different rates are comparable |
| height smoothing | Savitzky-Golay 15 s, order 2 | |
| vario averaging | 15 s | |
| turn window | 20 s | just under one circle (15–25 s) |
| turn threshold | 60 deg per 20 s | = 3 deg/s sustained |
| wind gate | ground speed > 0.85 × wind | drift is not straight flight |
| wind sample | ≥ 1.5 turns, ≥ 30 s, 4 fixes trimmed, ≤ 40 km/h | airspeed must average out over full circles |
| wind smoothing | 600 s running mean | otherwise episode steps look like fronts |
| climbing | vario > +0.10 m/s | |
| calm-air sink of the glider | −1.11 m/s | measured: mode over 4.19 M seconds of straight flight |
| air rising / calm / sinking / strong | w > +0.6 / ±0.6 / −1.5 | conventions on the movement of the air |
| minimum run | 20 s | shorter runs are absorbed |
| height tolerance | 60 m | the knee of the size/accuracy curve |
| position tolerance | 300 m | rarely binding on straight stretches |
| coordinates | 5 decimals | about 1 m — the raw fix |

Every one of these is a module constant at the top of `flightstates.py` and can
be changed in one place.

---

## The output line

```
id;yyyymmdd;SEG|SEG|...;END

SEG straight (G,T,L):  A,t,h,lat,lon
SEG circling (K,k):    A,t,h,lat,lon,turns,drift_kmh,drift_from_deg
END:                     t,h,lat,lon
```

**The first field is yours.** This script never writes a name there; by default
it writes the single letter `P`. Fill it with whatever suits you — an anonymised
pilot key, a flight number of your own, a constant, or nothing at all. `--id
TEXT` sets it; `--id name` uses the file name, which only makes sense on your
own archive, since IGC file names usually carry the pilot's name.

If you do put an anonymised *pilot* key there, something becomes possible that no
single flight can show: how one pilot's technique develops over the years — when
the circling gets tighter, when the straight climbing starts to appear, how the
glides change. Two things could come of that, and both are yours to decide. I
would study it, but **anonymously only** — never a named pilot, in any
publication of mine. And you could turn it into something for your own users, a
personal progress report for paying XCTrack subscribers, for instance. It is an
offer, not a request: nothing in this package needs the field to be filled.

`A` is the kind, `t` the second of the day (UTC) at which the segment
**begins**, `h` the altitude MSL in metres, `lat,lon` the position — all at the
beginning of the segment. The **end** of a segment is the **beginning of the
next**, so it is not written twice; only the last point of the flight gets an
entry of its own.

```
P;20230522;k,27039,1920,46.37603,8.02630,0.6,,|R,27084,1917,46.37443,8.02672|
K,27125,1875,46.37130,8.02435,11.3,3.6,131|…
```

With `--delta` every number is written as the difference to the previous one.
Nothing is lost — `read_line_delta()` on `example_line_delta.txt` returns
exactly what `read_line()` returns on `example_line.txt`, checked segment by
segment — the numbers merely get short:

```
P;20230522;k27039,1920,4637603,802630,0.6,,|L45,-3,-160,42|
K41,-42,-313,-237,11.3,3.6,131|…
```

`read_line()` and `read_line_delta()` in `flightstates.py` turn a line back into
a list of segments.

---

## Verification

`verify.py` draws the same picture twice: once from the real IGC file, once
from the text line alone, and prints the numeric comparison.

```bash
python3 verify.py flight.IGC --out check.png
```

For the day shown above:

```
height   : mean error  21.1 m, 90% under  51.7 m, largest  119 m
position : mean error    83 m, 90% under   183 m, largest  959 m
time share per state (real / reconstructed):
  circling climb        25.5 %  /  25.5 %
  circling, no gain      2.4 %  /   2.4 %
  straight climb        18.0 %  /  18.0 %
  air rising            10.0 %  /  10.0 %
  calm air              37.4 %  /  37.4 %
  sinking air            6.7 %  /   6.7 %
  strongly sinking air   0.0 %  /   0.0 %
wind : 52 measurements from 79 circling segments, mean 7.7 km/h, largest 19.4 km/h
```

![real against reconstructed](example_verify.png)

The position error is the price of the straight lines: while circling, the
reconstruction draws the chord instead of the circles. That is also why the
wind is stored rather than derived.

---

## Size and time

Measured on the 489 flights (2 066 flying hours, full 1 m / 1 s resolution,
`--delta`, `xz -6`):

```
8.2 bytes per segment            858 bytes per flight       203 bytes per flying hour
segmentation  3.2 ms per flying hour   (Apple Silicon, one core, IGC read included)
              9.6 ms per flying hour   (older x86 core)
compression   0.08 ms per flying hour  — about 2 % of the work
```

Scaled two ways: per climb (2.30 segments per circling piece, so 27.5 million
climbs become 63 million segments) that is **0.52 GB**; per flying hour, taking
three million flights of under two hours, **1.3 GB**. The first is the floor —
these are dense cross-country hours — and the second the ceiling. Reckon on
**half a gigabyte to a gigabyte and a bit**, compressed, and **one to six
core-hours** of computing: an hour and a half on four cores.

Run it in parallel and concatenate:

```bash
for k in 1 2 3 4; do
  python3 flightstates.py --delta --part=$k/4 "flights/**/*.IGC" > part$k.txt &
done
wait
cat part*.txt | xz -6 > states.txt.xz
```

Each line is independent, so the output can be processed line by line without
loading the file.

---

## Files

| File | what it is |
|---|---|
| `flightstates.py` | the segmenter — runs on its own, needs nothing else from here |
| `verify.py` | real against reconstructed, picture and numbers |
| `chart.py` | one flying day in five states, as a plate |
| `example_line.txt` | one flight, full form |
| `example_line_delta.txt` | the same flight, compact form |
| `example_day.png`, `example_verify.png` | the two pictures above |
| `README.md`, `readme.html` | this text — as source and as a page to open |

## Origin and limits

* Layer 1 follows an existing fingerprint pipeline; layers 2 and 3 and the
  state definitions are this work.
* The wind method is taken over unchanged from a tested implementation and is
  not claimed as new here.
* Height comes from the barometer when its spread says it is real, otherwise
  from GPS.
* The date comes from the `HFDTE` record; if it is missing, from the file name.
  Times are UTC.
* Flights without valid B records are skipped and reported on stderr.
* The states are a decomposition, not an observation. Where a climb begins and
  ends is a decision. All the decisions are the module constants above; change
  one and the whole output changes consistently.

Jörg Korner, 2026. Free to use.
