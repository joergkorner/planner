"""
flightstates.py — flight track in, state list out.

The unit is the SECOND, not the thermal. Every second of the track gets two
properties — is the pilot circling, and what is the height doing — and a
segment is a contiguous run of equal seconds. A thermal is therefore a run of
"circling and climbing", no more and no less, and it stands beside "straight
and climbing" as an equal.

Five kinds:
    K  circling climb        (thermal)
    k  circling, no gain     (failed attempt, sinking out in a turn)
    G  straight climb        (ridge lift, convergence, cloud street)
    T  carried               (reduced sink, no circling)
    L  glide

Line format (one flight, one line, fields separated by semicolons):

    id;yyyymmdd;SEG|SEG|...;END

  SEG straight (G,T,L):   A,t,h,lat,lon
  SEG circling (K,k):     A,t,h,lat,lon,turns,drift_kmh,drift_from_deg
  END:                      t,h,lat,lon

  A       kind (one letter)
  t       second of the day UTC at which the segment BEGINS
  h       altitude MSL in m at the beginning
  lat,lon position at the beginning, five decimals (about 1 m, as in kk7)

The END of a segment is the BEGINNING of the next — which is why it is not
written twice. Only the last point of the flight needs an entry of its own.

The wind belongs to the thermal and is written only there, measured by the
method of thermal_strategy.py: at least 1.5 full turns, at least 30 s, four
fixes trimmed at each end (entry and exit are not circling), drift above
40 km/h discarded. If the conditions are not met, both wind fields stay empty;
the turn count is written anyway.

Dependencies: numpy, pandas, scipy. Nothing else — this file runs on its own.

    python3 flightstates.py flights/*.IGC > states.txt
    python3 flightstates.py --delta flights/*.IGC > states.txt   (compact)

The first field is YOURS. This script never puts a name there; by default it
writes the single letter "P". Fill it with whatever suits you: an anonymised
pilot key, a flight number of your own, a constant, or nothing at all.

    --id TEXT     write TEXT in the first field (default "P")
    --id name     use the file name — only sensible on your own archive,
                  since IGC file names usually carry the pilot's name

If you put an anonymised PILOT key there, one thing becomes possible that no
single flight can show: how a pilot's technique develops over the years — when
the circles get tighter, when the straight climbing starts to appear, how the
glides change. Two things could come of that, and both are yours to decide. I
would study it, but ANONYMOUSLY ONLY — never a named pilot, in any publication
of mine. And you could turn it into something for your own users, a personal
progress report for paying XCTrack subscribers, for instance. Nothing here
needs the field to be filled.

Author: Joerg Koerner, 2026. Free to use.
"""
import sys, re
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.signal import savgol_filter

# ---------------------------------------------------------------- thresholds
TURN_WINDOW = 20      # s, centred window for the heading change
TURN_LIMIT  = 60.0    # deg per 20 s -> 3 deg/s sustained = circling
WIND_FACTOR  = 0.85    # ground speed must exceed 0.85 x wind, else it is drift
CLIMBS      = 0.10    # m/s
CARRIES      = -0.50   # m/s, half the normal sink rate
MIN_RUN_S     = 20      # s, shorter circling/straight pieces are absorbed
# Simplification of the straight pieces (Douglas-Peucker). A corner is set
# only where a straight line would otherwise be off by more than this.
TOL_H       = 60.0    # m, height
TOL_XY      = 300.0   # m, ground plan
COORD_DECIMALS  = 5       # decimals of the position (5 = about 1 m, as in kk7)
# wind measurement (taken over from thermal_strategy.py)
W_MIN_TURNS = 1.5
W_MIN_DUR  = 30     # s
W_TRIM       = 4      # Fixes an jedem Ende abschneiden
W_MAX_DRIFT  = 40.0   # km/h
W_SMOOTH      = 600    # s, smoothing of the wind series between measurements

KINDS = "KkGTL"


# ---------------------------------------------------------------- read IGC
def read_igc(path):
    t, la, lo, ab, ag = [], [], [], [], []
    day = 0
    with open(path, "r", encoding="latin-1", errors="ignore") as f:
        for z in f:
            if z.startswith("HFDTE") and not day:
                d = re.sub(r"[^0-9]", "", z[5:])
                if len(d) >= 6:
                    j = int(d[4:6]); j += 2000 if j < 80 else 1900
                    day = j * 10000 + int(d[2:4]) * 100 + int(d[0:2])
                continue
            if not z.startswith("B") or len(z) < 35:
                continue
            try:
                t.append(int(z[1:3]) * 3600 + int(z[3:5]) * 60 + int(z[5:7]))
                la.append((int(z[7:9]) + int(z[9:14]) / 60000.0) * (1 if z[14] == "N" else -1))
                lo.append((int(z[15:18]) + int(z[18:23]) / 60000.0) * (1 if z[23] == "E" else -1))
                ab.append(int(z[25:30])); ag.append(int(z[30:35]))
            except ValueError:
                continue
    if len(t) < 60:
        raise ValueError("zu wenige gueltige B-Saetze")
    if not day:
        m = re.search(r"(20\d\d)[-_.]?(\d\d)[-_.]?(\d\d)", Path(path).name)
        day = int(m.group(1)) * 10000 + int(m.group(2)) * 100 + int(m.group(3)) if m else 0
    t = np.array(t, float)
    jump = np.concatenate(([0], np.cumsum(np.diff(t) < 0) * 86400.0))  # midnight rollover
    t += jump
    ab = np.array(ab, float); ag = np.array(ag, float)
    alt = ab if ab.std() > 1 else ag
    return day, float(t[0]), pd.DataFrame(dict(t=t - t[0], lat=la, lon=lo, alt=alt))


def resample_1hz(df):
    """Resample to 1 Hz, smooth the height, derive vario and ground speed."""
    df = df.sort_values("t").drop_duplicates("t")
    idx = np.arange(0, int(df["t"].iloc[-1]) + 1)
    out = pd.DataFrame(dict(t=idx.astype(float)))
    for s in ("lat", "lon", "alt"):
        out[s] = np.interp(idx, df["t"].to_numpy(), df[s].to_numpy())
    n = len(out)
    fen = min(15, n if n % 2 else n - 1)
    out["alt_g"] = savgol_filter(out["alt"], max(fen, 5), 2) if n > 5 else out["alt"]
    out["vario"] = pd.Series(np.gradient(out["alt_g"].to_numpy())).rolling(
        15, center=True, min_periods=1).mean().to_numpy()
    la, lo = out["lat"].to_numpy(), out["lon"].to_numpy()
    out["x"] = np.radians(lo - lo[0]) * 6371000.0 * np.cos(np.radians(la.mean()))
    out["y"] = np.radians(la - la[0]) * 6371000.0
    d = np.zeros(n)
    d[1:] = np.hypot(np.diff(out["x"]), np.diff(out["y"]))
    out["gs"] = d * 3.6
    return out


def dp_corners(x, y, tol):
    """Douglas-Peucker on a curve; returns the indices of the corners.
    A point survives only if a line without it would be off by more than tol."""
    n = len(x)
    if n < 3:
        return list(range(n))
    keep = np.zeros(n, bool)
    keep[0] = keep[-1] = True
    stack = [(0, n - 1)]
    while stack:
        a, b = stack.pop()
        if b <= a + 1:
            continue
        dx, dy = x[b] - x[a], y[b] - y[a]
        length = np.hypot(dx, dy)
        if length < 1e-9:
            dist = np.hypot(x[a + 1:b] - x[a], y[a + 1:b] - y[a])
        else:
            dist = np.abs(dy * (x[a + 1:b] - x[a])
                          - dx * (y[a + 1:b] - y[a])) / length
        i = int(np.argmax(dist))
        if dist[i] > tol:
            k = a + 1 + i
            keep[k] = True
            stack.append((a, k)); stack.append((k, b))
    return list(np.flatnonzero(keep))


def runs_of(maske):
    """[(a,b)] of the contiguous True stretches."""
    m = np.concatenate(([False], maske.astype(bool), [False]))
    k = np.flatnonzero(np.diff(m.astype(np.int8)))
    return list(zip(k[0::2], k[1::2] - 1))


# ---------------------------------------------------------------- circling
def turn_signal(df):
    la, lo = df["lat"].to_numpy(), df["lon"].to_numpy()
    y = np.sin(np.radians(lo[1:] - lo[:-1])) * np.cos(np.radians(la[1:]))
    x = (np.cos(np.radians(la[:-1])) * np.sin(np.radians(la[1:]))
         - np.sin(np.radians(la[:-1])) * np.cos(np.radians(la[1:]))
         * np.cos(np.radians(lo[1:] - lo[:-1])))
    course = (np.degrees(np.arctan2(y, x)) + 360.0) % 360.0
    dh = np.zeros(len(df))
    dh[2:] = (np.diff(course) + 180.0) % 360.0 - 180.0      # degrees per second
    net = pd.Series(dh).rolling(TURN_WINDOW, center=True,
                                  min_periods=5).sum().to_numpy()
    return dh, np.nan_to_num(net)


def drift_sample(df, a, b, dh):
    """Wind sample of one circling piece, after thermal_strategy: (turns, vx, vy)
    or (turns, nan, nan) if the conditions are not met."""
    turns = abs(float(dh[a:b + 1].sum())) / 360.0
    if b - a < W_MIN_DUR or turns < W_MIN_TURNS:
        return turns, np.nan, np.nan
    a2, b2 = a + W_TRIM, b - W_TRIM
    dt = float(b2 - a2)
    if dt < 20:
        return turns, np.nan, np.nan
    x, y = df["x"].to_numpy(), df["y"].to_numpy()
    vx = (x[b2] - x[a2]) / dt
    vy = (y[b2] - y[a2]) / dt
    if np.hypot(vx, vy) * 3.6 > W_MAX_DRIFT:
        return turns, np.nan, np.nan
    return turns, vx, vy


def wind_series(df, dh, net):
    """Wind per second from the circling pieces; only for the state rule."""
    n = len(df)
    tp, ex, ey = [], [], []
    for a, b in runs_of(np.abs(net) > TURN_LIMIT):
        _, vx, vy = drift_sample(df, a, b, dh)
        if np.isfinite(vx):
            tp.append(0.5 * (a + b)); ex.append(vx); ey.append(vy)
    i = np.arange(n, dtype=float)
    if len(tp) >= 2:
        wx, wy = np.interp(i, tp, ex), np.interp(i, tp, ey)
    elif tp:
        wx, wy = np.full(n, ex[0]), np.full(n, ey[0])
    else:
        wx, wy = np.zeros(n), np.zeros(n)
    wx = pd.Series(wx).rolling(W_SMOOTH, center=True, min_periods=1).mean().to_numpy()
    wy = pd.Series(wy).rolling(W_SMOOTH, center=True, min_periods=1).mean().to_numpy()
    return wx, wy, np.hypot(wx, wy) * 3.6


# ---------------------------------------------------------------- states
def circling_per_second(df, net, wind_kmh):
    """First axis: is he circling or not."""
    return (np.abs(net) > TURN_LIMIT) | (df["gs"].to_numpy()
                                           <= WIND_FACTOR * wind_kmh)


def _merge(z, min_s):
    """Absorb runs that are too short into the longer neighbour."""
    z = np.asarray(z).copy()
    while True:
        gr = np.concatenate(([0], np.flatnonzero(np.diff(z)) + 1, [len(z)]))
        dur = np.diff(gr)
        if len(dur) <= 1 or dur.min() >= min_s:
            break
        i = int(np.argmin(dur))
        left = dur[i - 1] if i > 0 else -1
        right = dur[i + 1] if i + 1 < len(dur) else -1
        z[gr[i]:gr[i + 1]] = z[gr[i] - 1] if left >= right else z[gr[i + 1]]
    gr = np.concatenate(([0], np.flatnonzero(np.diff(z)) + 1, [len(z)]))
    return [(int(gr[i]), int(gr[i + 1] - 1), z[gr[i]])
            for i in range(len(gr) - 1)]


def to_runs(df, circ, min_s=MIN_RUN_S):
    """Runs of equal state.

    The track is first split into circling and straight — a thermal therefore
    stays whole and does not fall apart at every dip in the climb.

    A straight piece is then NOT chopped up by a per-second vario threshold,
    but divided by the height profile and the ground track themselves: only as
    many corners are set as are needed so that the height is never off by more
    than TOL_H and the position never by more than TOL_XY. Each resulting
    piece takes its kind from its OWN slope. This removes the flicker between
    climbing and gliding without losing any information larger than the
    tolerance.

    A circling piece takes its kind from the gain over the WHOLE piece.
    """
    h = df["alt_g"].to_numpy()
    x, y = df["x"].to_numpy(), df["y"].to_numpy()
    t = np.arange(len(h), dtype=float)
    out = []
    for a, b, k in _merge(circ.astype(np.int8), min_s):
        if k:                                    # circling: K or k for the whole piece
            rate = (h[b] - h[a]) / max(b - a, 1)
            out.append((a, b, 0 if rate > CLIMBS else 1))
            continue
        if b - a < 2:
            out.append((a, b, 4)); continue
        kn = set(dp_corners(t[a:b + 1], h[a:b + 1], TOL_H))
        kn |= set(dp_corners(x[a:b + 1], y[a:b + 1], TOL_XY))
        kn = sorted(kn)
        for i in range(len(kn) - 1):
            p, q = a + kn[i], a + kn[i + 1]
            rate = (h[q] - h[p]) / max(q - p, 1)
            out.append((p, q - 1 if i < len(kn) - 2 else b,
                        2 if rate > CLIMBS else (3 if rate > CARRIES else 4)))
    # merge equal kinds that now abut
    fine = [list(out[0])]
    for a, b, k in out[1:]:
        if k == fine[-1][2] and a == fine[-1][1] + 1:
            fine[-1][1] = b
        else:
            fine.append([a, b, k])
    return [tuple(x) for x in fine]


def segments(path):
    day, t0, raw = read_igc(path)
    df = resample_1hz(raw)
    dh, net = turn_signal(df)
    wx, wy, wkmh = wind_series(df, dh, net)
    circ = circling_per_second(df, net, wkmh)
    la, lo = df["lat"].to_numpy(), df["lon"].to_numpy()
    h = df["alt_g"].to_numpy()
    out = []
    stuecke = to_runs(df, circ)
    for a, b, k in stuecke:
        kind = KINDS[k]
        s = dict(kind=kind, t=int(round(t0 + a)) % 86400, h=int(round(h[a])),
                 la=float(la[a]), lo=float(lo[a]), a=a, b=b)
        if kind in "Kk":
            kr, vx, vy = drift_sample(df, a, b, dh)
            s["turns"] = round(kr, 1)
            if np.isfinite(vx):
                s["drift"] = round(float(np.hypot(vx, vy)) * 3.6, 1)
                # meteorological: the direction the air comes FROM
                s["dir"] = int(round((np.degrees(np.arctan2(-vx, -vy)) + 360) % 360))
            else:
                s["drift"] = None; s["dir"] = None
        out.append(s)
    end = (int(round(t0 + len(df) - 1)) % 86400, int(round(h[-1])),
            float(la[-1]), float(lo[-1]))
    return day, out, end, df


def line(kennung, day, segs, end):
    st = []
    for s in segs:
        b = (f"{s['kind']},{s['t']},{s['h']},"
             f"{s['la']:.{COORD_DECIMALS}f},{s['lo']:.{COORD_DECIMALS}f}")
        if s["kind"] in "Kk":
            d = "" if s["drift"] is None else f"{s['drift']:.1f}"
            r = "" if s["dir"] is None else str(s["dir"])
            b += f",{s['turns']:.1f},{d},{r}"
        st.append(b)
    return (f"{kennung};{day};" + "|".join(st)
            + f";{end[0]},{end[1]},"
              f"{end[2]:.{COORD_DECIMALS}f},{end[3]:.{COORD_DECIMALS}f}")


def line_delta(kennung, day, segs, end):
    """The same line, but every number as the difference to the previous one.
    Nothing is lost — read_line_delta() gives back exactly what read_line()
    gives — the numbers merely get short."""
    st, v = [], None
    for s_ in segs:
        la, lo = round(s_["la"] * 10**COORD_DECIMALS), round(s_["lo"] * 10**COORD_DECIMALS)
        if v is None:
            b = f"{s_['kind']}{s_['t']},{s_['h']},{la},{lo}"
        else:
            b = (f"{s_['kind']}{s_['t']-v[0]},{s_['h']-v[1]},"
                 f"{la-v[2]},{lo-v[3]}")
        if s_["kind"] in "Kk":
            d = "" if s_["drift"] is None else f"{s_['drift']:.1f}"
            r = "" if s_["dir"] is None else str(s_["dir"])
            b += f",{s_['turns']:.1f},{d},{r}"
        st.append(b); v = (s_["t"], s_["h"], la, lo)
    e = (end[0] - v[0], end[1] - v[1],
         round(end[2] * 10**COORD_DECIMALS) - v[2], round(end[3] * 10**COORD_DECIMALS) - v[3])
    return f"{kennung};{day};" + "|".join(st) + ";" + ",".join(str(z) for z in e)


def read_line_delta(zl):
    """Counterpart of line_delta()."""
    kennung, day, sr, er = zl.rstrip("\n").split(";")
    segs, v = [], None
    for stk in sr.split("|"):
        f = stk.split(",")
        t, h, la, lo = int(f[0][1:]), int(f[1]), int(f[2]), int(f[3])
        if v is not None:
            t += v[0]; h += v[1]; la += v[2]; lo += v[3]
        v = (t, h, la, lo)
        s_ = dict(kind=f[0][0], t=t, h=h, la=la / 10**COORD_DECIMALS, lo=lo / 10**COORD_DECIMALS)
        if s_["kind"] in "Kk":
            s_["turns"] = float(f[4])
            s_["drift"] = float(f[5]) if f[5] else None
            s_["dir"] = int(f[6]) if f[6] else None
        segs.append(s_)
    f = [int(z) for z in er.split(",")]
    end = (v[0] + f[0], v[1] + f[1], (v[2] + f[2]) / 10**COORD_DECIMALS, (v[3] + f[3]) / 10**COORD_DECIMALS)
    return kennung, int(day), segs, end


def read_line(zl):
    """Counterpart of line(): line -> (id, day, segments, end)."""
    kennung, day, sr, er = zl.rstrip("\n").split(";")
    segs = []
    for st in sr.split("|"):
        f = st.split(",")
        s = dict(kind=f[0], t=int(f[1]), h=int(f[2]), la=float(f[3]), lo=float(f[4]))
        if s["kind"] in "Kk":
            s["turns"] = float(f[5])
            s["drift"] = float(f[6]) if f[6] else None
            s["dir"] = int(f[7]) if f[7] else None
        segs.append(s)
    f = er.split(",")
    return kennung, int(day), segs, (int(f[0]), int(f[1]), float(f[2]), float(f[3]))


if __name__ == "__main__":
    argv = sys.argv[1:]
    short = "--delta" in argv
    if short:
        argv.remove("--delta")
    part = [a for a in argv if a.startswith("--part")]
    k, n = 1, 1
    if part:
        argv.remove(part[0])
        k, n = (int(x) for x in part[0].split("=")[1].split("/"))
    kennung = "P"
    if "--id" in argv:
        i = argv.index("--id"); kennung = argv[i + 1]; del argv[i:i + 2]
    argv = sorted(argv)[k - 1::n]
    for p in argv:
        try:
            day, segs, end, _ = segments(p)
            k_ = Path(p).stem if kennung == "name" else kennung
            f = line_delta if short else line
            print(f(k_, day, segs, end))
        except Exception as e:
            print(f"# {Path(p).name}: {type(e).__name__}: {e}", file=sys.stderr)
